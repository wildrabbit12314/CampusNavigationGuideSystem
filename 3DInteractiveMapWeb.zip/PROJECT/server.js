const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// Enable CORS to allow requests from the front end
app.use(cors());

// Middleware to parse JSON request body
app.use(express.json());

// Serve static files (HTML, CSS, JS, etc.) from the root directory
app.use(express.static(path.join(__dirname)));

// Create a MySQL connection pool
const db = mysql.createPool({
    host: 'localhost',
    user: 'root', // replace with your MySQL username
    password: '', // replace with your MySQL password
    database: 'campus_db', // Database name
});

// Test database connection
db.getConnection((err) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL database');
});
    
// Route to handle classroom finder search requests
app.get('/classroom', (req, res) => {
    const classroomCode = req.query.code; // Get classroom code from query string

    if (!classroomCode) {
        return res.status(400).send({ error: 'Classroom code is required' });
    }

    console.log("Classroom Code:", classroomCode); // Debugging log

    // Query the database for classroom details based on classroom_code
    const query = `
        SELECT 
            id, 
            classroom_code, 
            building_name, 
            object_name, 
            building_floor, 
            IFNULL(capacity, 'N/A') AS capacity
        FROM classrooms 
        WHERE classroom_code = ?
    `;
    const values = [classroomCode];

    db.execute(query, values, (err, results) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.status(500).send({ error: 'Database query failed' });
        }

        console.log("Results:", results); // Debugging log

        // Return the search results
        res.json(results);
    });
});
// Route to handle search requests
app.get('/search', (req, res) => {
    const searchTerm = req.query.term; // Get search term from query string

    if (!searchTerm) {
        return res.status(400).send({ error: 'Search term is required' });
    }

    console.log("Search Term:", searchTerm); // Debugging log

    // Query the database for places matching the search term
    const query = `
        SELECT 
            id, 
            place, 
            building_name, 
            object_name, 
            building_floor, 
            room_code, 
            IFNULL(NULLIF(description, ''), 'N/A') AS description
        FROM places 
        WHERE place LIKE ?
    `;
    const values = [`%${searchTerm}%`];

    db.execute(query, values, (err, results) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.status(500).send({ error: 'Database query failed' });
        }

        console.log("Results:", results);  // Debugging log

        // Return search results
        res.json(results);
    });
});

// Route to fetch all events
app.get('/events', (req, res) => {
    const query = `
        SELECT 
            id, 
            event_name, 
            location, 
            event_date, 
            event_time
        FROM campus_events
        ORDER BY event_date, event_time;
    `;

    db.execute(query, (err, results) => {
        if (err) {
            console.error("Error fetching events:", err);
            return res.status(500).send({ error: 'Database query failed' });
        }

        // Return all events
        res.json(results);
    });
});



// Route to serve the index.html file at the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});


// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});


// Initialize OrbitControls
// Initialize OrbitControls
const controls = new THREE.OrbitControls(camera, renderer.domElement);

controls.enableDamping = true;
controls.dampingFactor = 0.5;
controls.screenSpacePanning = true;
controls.rotateSpeed = 0.5;
controls.zoomSpeed = 3.0;
controls.panSpeed = 0.5;
controls.enableZoom = true;
controls.minDistance = 1400;
controls.maxDistance = 5000;
controls.enablePan = true;

// Limit vertical rotation
controls.minPolarAngle = 0; // Looking straight ahead (horizon)
controls.maxPolarAngle = Math.PI / 2; // Looking straight down at the object (no further down)

controls.mouseButtons = {
    LEFT: THREE.MOUSE.NONE,    // Left click for panning
    MIDDLE: THREE.MOUSE.ROTATE, // Middle click for rotation
    RIGHT: THREE.MOUSE.PAN     // Right click for panning (optional, or set to NONE)
};
// Update controls in the animation loop
// Modify your animate function to update camera info every frame
function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
    
}

// Disable right-click context menu
document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
});

// Disable key combinations for developer tools
document.addEventListener('keydown', (e) => {
    // Block F12
    if (e.key === 'F12') {
        e.preventDefault();
    }

    // Block Ctrl+Shift+I (Inspect), Ctrl+Shift+J (Console), Ctrl+U (View Source)
    if ((e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J')) || (e.ctrlKey && e.key === 'U')) {
        e.preventDefault();
    }
});


document.addEventListener('wheel', (event) => {
    if (event.ctrlKey) {
      event.preventDefault();
    }
  }, { passive: false });
  
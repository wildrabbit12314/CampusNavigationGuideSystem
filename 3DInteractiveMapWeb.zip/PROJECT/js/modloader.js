// Create scene, camera, and renderer for the 3D model
const scene = new THREE.Scene();

// Set background color of the scene to #D6D2CA
scene.background = new THREE.Color(0xFFFFFF);



const renderer = new THREE.WebGLRenderer({ 
    canvas: document.getElementById('three-canvas'),
    antialias: true
});
renderer.setSize(window.innerWidth * 0.7, window.innerHeight); // Set width for the 3D view area
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1;
renderer.gammaOutput = true;
renderer.gammaFactor = 2.2;


// Store references to each line
let yellowLine, bautistaLine, adminLine, mulitLine, danceLine, acadLine, chedLine, belmonteLine, techvocLine;
let currentLine = null; // Keep track of the currently shown line
let startObject = null; // Variable for the "Start" object
// Load .glb model
const loader = new THREE.GLTFLoader();
loader.load('NavigationModel.glb', function (gltf) {
    console.log("Model loaded successfully");
    const rootObject = gltf.scene;

    // Move the entire model down along the y-axis
    rootObject.position.y -= 400; // Adjust this value to control how much you want to move it down
    rootObject.position.x -= -225;

    rootObject.traverse((node) => {
        if (node.isMesh) {
            node.castShadow = true;    
            node.receiveShadow = true; 
            
            if (node.name === "Plane") {
                node.castShadow = false;
                node.receiveShadow = true;
            }

            if (node.name === "Start") {
                startObject = node; // Store reference to Start object
                startObject.visible = false; // Hide Start initially
            }

            // Store references to each line and hide them initially
            if (node.name === "YellowLine") {
                yellowLine = node;  // Store reference to YellowLine
                yellowLine.visible = false; // Hide YellowLine initially
            } else if (node.name === "BautistaLine") {
                bautistaLine = node; 
                bautistaLine.visible = false; // Hide BautistaLine initially
            } else if (node.name === "AdminLine") {
                adminLine = node; 
                adminLine.visible = false; // Hide AdminLine initially
            } else if (node.name === "MulitLine") {
                mulitLine = node; 
                mulitLine.visible = false; // Hide MultiLine initially
            } else if (node.name === "DanceLine") {
                danceLine = node; 
                danceLine.visible = false; // Hide DanceLine initially
            } else if (node.name === "HeadLine") {
                HeadLine = node; 
                HeadLine.visible = false; // Hide DanceLine initially
            } else if (node.name === "KorphilLine") {
                KorphilLine = node; 
                KorphilLine.visible = false; // Hide DanceLine initially
            } else if (node.name === "MotorParking") {
                MotorParking = node; 
                MotorParking.visible = false; // Hide DanceLine initially
            } else if (node.name === "OG") {
                OG = node; 
                OG.visible = false; // Hide DanceLine initially
            } else if (node.name === "CarsParking") {
                CarsParking = node; 
                CarsParking.visible = false; // Hide DanceLine initially
            } else if (node.name === "BikePark") {
                BikePark = node; 
                BikePark.visible = false; // Hide DanceLine initially
            } else if (node.name === "Triangle") {
                Triangle = node; 
                Triangle.visible = false; // Hide DanceLine initially
            } else if (node.name === "AcadLine") {
                acadLine = node; 
                acadLine.visible = false; // Hide AcadLine initially
            } else if (node.name === "ChedLine") {
                chedLine = node; 
                chedLine.visible = false; // Hide ChedLine initially
            } else if (node.name === "BelmonteLine") {
                belmonteLine = node; 
                belmonteLine.visible = false; // Hide BelmonteLine initially
            } else if (node.name === "Evacuation") {
                Evacuation = node; 
                Evacuation.visible = false; // Hide BelmonteLine initially
            } else if (node.name === "TechvocLine") {
                techvocLine = node; 
                techvocLine.visible = false; // Hide TechvocLine initially
            }
        }
    });

    scene.add(rootObject);
    animate();
}, undefined, function (error) {
    console.error("An error occurred:", error);
});

function selectObjectInScene(objectName) {
    // Assuming you're using Three.js and have your scene stored in a variable called 'scene'
    scene.traverse((object) => {
        if (object.name === objectName) {
            // Your selection logic here. For example:
            object.material.emissive.setHex(0xff0000); // Highlight the object in red
            camera.position.set(object.position.x, object.position.y, object.position.z + 5);
            controls.target.set(object.position.x, object.position.y, object.position.z);
        }
    });
}


document.addEventListener("DOMContentLoaded", () => {
    const mainPanel = document.getElementById("main-panel");
    const subPanels = document.querySelectorAll(".sub-panel");
    const panelButtons = document.querySelectorAll(".panel-button");
    const backButtons = document.querySelectorAll(".back-button");

    // Show selected panel and hide the main panel
    panelButtons.forEach(button => {
        button.addEventListener("click", () => {
            const targetPanelId = button.getAttribute("data-panel");
            document.getElementById(targetPanelId).classList.add("active");
            mainPanel.classList.remove("active");
        });
    });

    // Back to main panel
    backButtons.forEach(button => {
        button.addEventListener("click", () => {
            subPanels.forEach(panel => panel.classList.remove("active"));
            mainPanel.classList.add("active");
        });
    });

    // Show the main panel initially
    mainPanel.classList.add("active");
});

// Function to map building names to image URLs
function getImageForBuilding(buildingName) {
    const buildingImageMap = {
        'Technical Vocational Building': 'img/techvoc.jpg',
        'Yellow Building': 'img/yellowbuilding.jpg',
        'Administration Building': 'img/admin.jpg',
        'Baustista Building': 'img/bautista.jpg',
        'Korea-Philippines Building': 'img/korphil.jpg',
        'Metal Casting Building': 'img/ched.jpg',
        'Belmonte Hall': 'img/belmonte.jpg',
        'Headquarters': 'img/hq.jpg',
        'Academic Building': 'img/acad.jpg',
        'Multi-Purpose Hall': 'img/multi.jpg',
        // Add other buildings and their corresponding images here
    };

    // Return the image URL based on the building name
    return buildingImageMap[buildingName] || 'img/default.jpg'; // Default image if building name is not in the map
}

async function findClassroom() {
    const classroomCode = document.getElementById('classroom-input').value.trim();

    if (!classroomCode) {
        alert('Please enter a classroom code');
        return;
    }

    // Make a GET request to the server to fetch classroom details
    const response = await fetch(`http://localhost:3000/classroom?code=${classroomCode}`);
    const data = await response.json();

    // Display classroom results in the #classroom-results div
    const resultsDiv = document.getElementById('classroom-results');
    resultsDiv.innerHTML = ''; // Clear previous results

    if (data.length > 0) {
        data.forEach(result => {
            const resultDiv = document.createElement('div');
            resultDiv.classList.add('classroom-result');

            resultDiv.innerHTML = `
                <h3>${result.classroom_code}</h3>
                <p><strong>Building Name:</strong> ${result.building_name}</p>
                <p><strong>Building Floor:</strong> ${result.building_floor}</p>
                <p><strong>Capacity:</strong> ${result.capacity}</p>
            `;

            resultsDiv.appendChild(resultDiv);

            // Automatically select the building object if its object_name matches
            if (result.object_name) {
                activateBuildingSelection(result.object_name);
            }
        });
    } else {
        resultsDiv.innerHTML = '<p>No classroom found.</p>';
    }
}

async function searchPlace() {
    const searchTerm = document.getElementById('search-input').value.trim();
    
    if (!searchTerm) {
        alert('Please enter a search term');
        return;
    }

    // Make a GET request to the Node.js server to fetch search results
    const response = await fetch(`http://localhost:3000/search?term=${searchTerm}`);
    const data = await response.json();

    // Display search results in the #search-results div
    const resultsDiv = document.getElementById('search-results');
    resultsDiv.innerHTML = ''; // Clear previous results

    if (data.length > 0) {
        data.forEach(result => {
            const resultDiv = document.createElement('div');
            resultDiv.classList.add('search-result');

            // Get the image URL based on the building name
            const buildingImage = getImageForBuilding(result.building_name);

            resultDiv.innerHTML = ` 
                <div class="result-card-content">
                    <div class="result-image">
                        <img src="${buildingImage}" alt="${result.building_name}" />
                    </div>
                    <h3>${result.place}</h3>
                    <p><strong>Building Name:</strong> ${result.building_name}</p>
                    <p><strong>Building Floor:</strong> ${result.building_floor}</p>
                    <p><strong>Room Code:</strong> ${result.room_code}</p>
                    <p><strong>Description:</strong> ${result.description}</p>
                </div>
            `;

            // Add an X button to close the card
            const closeButton = document.createElement('button');
            closeButton.classList.add('close-button');
            closeButton.innerHTML = 'X';
            closeButton.onclick = () => {
                resultDiv.remove();  // Remove the specific result card when clicked
            };

            // Prepend the close button to the result card
            resultDiv.prepend(closeButton);

            resultsDiv.appendChild(resultDiv);

            // Automatically select the building if its object_name matches
            if (result.object_name) {
                activateBuildingSelection(result.object_name);
            }
        });
    } else {
        resultsDiv.innerHTML = '<p>No results found.</p>';
    }
}




// Function to automatically select and activate any building by its object_name
function activateBuildingSelection(objectName) {
    const objectToSelect = scene.getObjectByName(objectName);

    if (objectToSelect) {
        // Trigger the selection process (you might need to adjust this to your exact implementation)
        selectSingleObject(objectToSelect);

        // Optionally, you could focus the camera on the selected building or show additional information
        nameDisplay.textContent = `Selected: ${objectToSelect.name}`;
    } else {
        console.warn(`${objectName} not found in the scene.`);
    }
}



// Hide the loading screen once the page is loaded
window.addEventListener('load', function () {
    const loadingScreen = document.getElementById('loading-screen');
    
    // Optional: Set a delay before starting the fade-out for a longer loading duration
    setTimeout(function () {
        loadingScreen.style.opacity = '0'; // Fade out the loading screen
        setTimeout(function () {
            loadingScreen.style.display = 'none'; // Remove the loading screen from view after fade-out
        }, 1000); // Match this duration with the opacity transition
    }, 1300); // Adjust the delay here (e.g., 3000 ms = 3 seconds)
});

const cardContainer = document.getElementById('card-container');

// Fetch all events from the server
function fetchAllEvents() {
    fetch('/events')
        .then((response) => {
            if (!response.ok) {
                throw new Error('Failed to fetch events');
            }
            return response.json();
        })
        .then((data) => {
            populateEventCards(data);
        })
        .catch((error) => {
            console.error('Error fetching events:', error);
        });
}

function populateEventCards(data) {
    // Clear previous cards
    cardContainer.innerHTML = '';

    if (data.length === 0) {
        cardContainer.innerHTML = '<p>No events found</p>';
        return;
    }

    // Create a card for each event
    data.forEach((event) => {
        const card = document.createElement('div');
        card.classList.add('card');

        // Format date and time
        const eventDate = new Date(event.event_date).toLocaleDateString();
        const eventTime = new Date(`1970-01-01T${event.event_time}Z`).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        card.innerHTML = `
            <h3>${event.event_name}</h3>
            <p><strong>Location:</strong> ${event.location}</p>
            <p><strong>Date:</strong> ${eventDate}</p>
            <p><strong>Time:</strong> ${eventTime}</p>
        `;

        // Create the "Find" button
        const findButton = document.createElement('button');
        findButton.textContent = 'Find';
        findButton.classList.add('find-button');

        // Add event listener to the "Find" button
        findButton.addEventListener('click', () => {
            // Set the search input value to the event location
            document.getElementById('search-input').value = event.location;

            // Trigger navigation to search panel
            document.getElementById('search-panel').classList.add('active');  // Make search panel visible
            document.getElementById('event-panel').classList.remove('active');  // Hide event panel
        });

        // Append the button to the card
        card.appendChild(findButton);

        // Add hover/click effects
        card.addEventListener('click', () => {
            // Trigger your Three.js navigation logic here (if needed)
        });

        cardContainer.appendChild(card);
    });
}

// Fetch all events on page load
document.addEventListener('DOMContentLoaded', fetchAllEvents);

// Get references to the elements
const exportButton = document.getElementById("export-button");
const qrCodeContainer = document.getElementById("qr-code-container");
const closeButton = document.getElementById("close-qr-code");

// Show the QR code popup when the export button is clicked
exportButton.addEventListener("click", function() {
    qrCodeContainer.style.display = "flex"; // Display the QR code popup
});

// Close the QR code popup when the close button is clicked
closeButton.addEventListener("click", function() {
    qrCodeContainer.style.display = "none"; // Hide the QR code popup
});


// JavaScript to toggle visibility of classroom search section
document.getElementById('toggle-classroom-button').addEventListener('click', function () {
    const classroomSection = document.getElementById('classroom-search-section');
    classroomSection.classList.toggle('hidden');
});

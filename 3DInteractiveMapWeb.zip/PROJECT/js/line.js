
// Function to show line for the selected building
function showLineForBuilding(buildingName) {
    let lineToShow = null;
    switch (buildingName) {
        case "YellowBldg":
            lineToShow = yellowLine;
            break;
        case "BautistaBldg":
            lineToShow = bautistaLine;
            break;
        case "KorphilBldg":
            lineToShow = korphilLine;
            break;
        case "HQ":
            lineToShow = headLine;
            break;
        case "AdminBldg":
            lineToShow = adminLine;
            break;
        case "MultiBldg":
            lineToShow = mulitLine;
            break;
        case "DanceBldg":
            lineToShow = danceLine;
            break;
        case "AcadBldg":
            lineToShow = acadLine;
            break;
        case "ChedBldg":
            lineToShow = chedLine;
            break;
        case "BelmonteBldg":
            lineToShow = belmonteLine;
            break;
        case "TechvocBldg":
            lineToShow = techvocLine;
            break;
    }

    if (lineToShow) {
        lineToShow.visible = true; // Show the selected line
        gsap.to(lineToShow.material, { opacity: 1, duration: 0.5 }); // Fade in the line
    
        if (startObject) {
            startObject.visible = true; // Show the Start object when a building is clicked
        }}
}
    
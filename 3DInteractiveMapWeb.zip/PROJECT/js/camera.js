const cameraSettings = {
    'YellowBldg': {
        position: new THREE.Vector3(-700, 3500, 2930), // Camera position coordinates (x, y, z)
        lookAt: new THREE.Vector3(50, 0, 0) // Point the camera is looking at (x, y, z)
    },
    'TechvocBldg': {
        position: new THREE.Vector3(600, 1800, -5600),
        lookAt: new THREE.Vector3(0, 0, 0)
    },
    'BelmonteBldg': {
        position: new THREE.Vector3(-2400, 7200, 5000),
        lookAt: new THREE.Vector3(0, 0, 0)
    },
    'AcadBldg': {
        position: new THREE.Vector3(4000, 4200, 3930),
        lookAt: new THREE.Vector3(0, 0, 0)
    },
    'BautistaBldg': {
        position: new THREE.Vector3(-4000, 3200, 6930),
        lookAt: new THREE.Vector3(0, 0, 0)
    },
    'KorphilBldg': {
        position: new THREE.Vector3(400, 1200, 3930),
        lookAt: new THREE.Vector3(0, 0, 0)
    },
    'MultiBldg': {
        position: new THREE.Vector3(12400, 7200, 4930),
        lookAt: new THREE.Vector3(0, 0, 0)
    },
    'HQ': {
        position: new THREE.Vector3(12400, 15200,4930),
        lookAt: new THREE.Vector3(0, 0, 0)
    },
    'AdminBldg': {
        position: new THREE.Vector3(400, 1200, 3930),
        lookAt: new THREE.Vector3(0, 0, 0)
    },

    'ChedBldg': {
        position: new THREE.Vector3(400, 1200, 3930),
        lookAt: new THREE.Vector3(0, 0, 0)
    },

    'DanceBldg': {
        position: new THREE.Vector3(400, 1200, 3930),
        lookAt: new THREE.Vector3(0, 0, 0)
    },
};


// Create an orthographic camera
const aspect = window.innerWidth / window.innerHeight;
const frustumSize = 3800; // Increased frustum size for a larger view

const camera = new THREE.OrthographicCamera(
    -frustumSize * aspect / 2, // left
    frustumSize * aspect / 2,   // right
    frustumSize / 2,            // top
    -frustumSize / 2,           // bottom
    0.1,                        // near
    10000                       // far
);

// Set initial camera position to a farther view
camera.position.set(10000, 4000, 9000); // Increase these values for a farther position
camera.lookAt(0, 0, 0); // Focus on the center of the scene

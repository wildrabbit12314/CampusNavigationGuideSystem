const searchButton = document.getElementById('search-button');
const searchInput = document.getElementById('search-input');

searchButton.addEventListener('click', function() {
    const searchTerm = searchInput.value;
    
    if (searchTerm) {
        // Send a request to the server with the search term
        fetch(`http://localhost:3000/search?term=${searchTerm}`)
            .then(response => response.json())
            .then(data => {
                if (data.length > 0) {
                    // Extract the object_name from the first result
                    const objectName = data[0].object_name;
                    if (objectName) {
                        activateObjectByName(objectName);  // Activate the object based on object_name
                    } else {
                        alert("No object associated with this place.");
                    }
                } else {
                    alert("No matching places found.");
                }
            })
            .catch(error => {
                console.error("Error fetching search results:", error);
            });
    }
});

// Function to activate an object based on its name
function activateObjectByName(objectName) {
    // Check if the object exists in the scene
    const object = scene.getObjectByName(objectName);

    if (object) {
        console.log(`Activating object: ${objectName}`);  // Debugging log
        selectSingleObject(object); // Trigger the selectSingleObject function to activate it
    } else {
        console.warn(`Object with name "${objectName}" not found in the scene`);
    }
}

// Function to handle object selection (already defined in your previous code)
function selectSingleObject(object) {
    if (isAnimating) return; // Prevent selection if animating

    // Hide the previously selected object's line and Start object
    if (selectedObject && selectedObject !== object) {
        resetObjectColor(selectedObject); // Reset the previous building's color
        resetSelection(); 
    }

    selectedObject = object;

    selectedObject.traverse(function (child) {
        if (child.isMesh) {
            child.selected = true;
            child.originalColor = child.originalColor || child.material.color.clone();

            const blinkDuration = 0.3; 
            const blinkTimes = 8; 
            isAnimating = true; 
            isBlinking = true; // Set the blinking flag

            // Change color to blue during blinking
            child.material.color.setRGB(0, 0, 1); 

            let blinkTween = gsap.timeline({ repeat: blinkTimes - 1, yoyo: true });
            blinkTween.to(child.material.color, { r: 0, g: 0, b: 1, duration: blinkDuration })
                .to(child.material.color, { r: child.originalColor.r, g: child.originalColor.g, b: child.originalColor.b, duration: blinkDuration });

            blinkTween.eventCallback('onComplete', () => {
                // Keep the building blue after blinking is done
                child.material.color.setRGB(0, 0, 1);
                isAnimating = false; // Allow new selections after blinking
                isBlinking = false; // Reset blinking flag
            });
        }
    });

    nameDisplay.textContent = selectedObject.name ? selectedObject.name : 'Unnamed Object';

    const settings = cameraSettings[selectedObject.name];

    if (settings) {
        gsap.to(camera.position, {
            x: settings.position.x,
            y: settings.position.y,
            z: settings.position.z,
            duration: 1,
            onUpdate: () => {
                camera.lookAt(settings.lookAt);
            }
        });

        // Show the line and Start object for the selected building
        const lineToShow = showLineForBuilding(selectedObject.name);
        if (lineToShow) {
            currentLine = lineToShow; // Update currentLine
            gsap.to(currentLine.material, { opacity: 1, duration: 1.5 }); // Fade in the line

            if (startObject) {
                startObject.visible = true; // Show the Start object when a building is clicked
            }
        }
    } else {
        console.warn('No camera settings found for this object');
    }
}






function searchClassroom() {
    const searchTerm = document.getElementById('classroom-search-input').value.trim();
    
    if (!searchTerm) {
        alert('Please enter a classroom name');
        return;
    }

    // Perform the classroom search (e.g., via an API or a local search function)
    console.log('Searching for classroom:', searchTerm);
    // Implement your search logic here...
}

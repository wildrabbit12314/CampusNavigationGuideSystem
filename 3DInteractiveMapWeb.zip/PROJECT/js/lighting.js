
// Add ambient light (keeps a soft base lighting in the scene)
const ambientLight = new THREE.AmbientLight(0xffffff, 0.1);
scene.add(ambientLight);

// Add blue directional sunlight
const blueSunLight = new THREE.DirectionalLight(0x87CEFA, 0.4); // Light blue color, lighter tone
blueSunLight.position.set(100, 100, 100);
blueSunLight.castShadow = true;
blueSunLight.shadow.mapSize.width = 2048;
blueSunLight.shadow.mapSize.height = 2048;
blueSunLight.shadow.camera.near = 1;
blueSunLight.shadow.camera.far = 1500;
scene.add(blueSunLight);

// Add orange directional sunlight for a warmer tone
const orangeSunLight = new THREE.DirectionalLight(0xFFA500, 0.4); // Soft orange color
orangeSunLight.position.set(-100, 100, -100);
orangeSunLight.castShadow = true;
orangeSunLight.shadow.mapSize.width = 2048;
orangeSunLight.shadow.mapSize.height = 2048;
orangeSunLight.shadow.camera.near = 1;
orangeSunLight.shadow.camera.far = 1500;
scene.add(orangeSunLight);

const whiteSunLight = new THREE.DirectionalLight(0xffffff, 0.2); // White color
whiteSunLight.position.set(-100, 100, 100); // Position opposite to blue light
whiteSunLight.castShadow = true;
whiteSunLight.shadow.mapSize.width = 2048;
whiteSunLight.shadow.mapSize.height = 2048;
whiteSunLight.shadow.camera.near = 1;
whiteSunLight.shadow.camera.far = 1500;
scene.add(whiteSunLight);

// Optionally, you can add a sun mesh to visually represent the sun
const sunGeometry = new THREE.SphereGeometry(50, 32, 32);
const sunMaterial = new THREE.MeshBasicMaterial({ color: 0xffff00 });
const sun = new THREE.Mesh(sunGeometry, sunMaterial);
sun.position.set(100, 100, 100);
scene.add(sun);

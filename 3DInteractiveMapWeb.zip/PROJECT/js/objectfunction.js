

// Raycaster and mouse
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
let isAnimating = false; 
let selectedObject = null;

// Mouse movement tracking
let isMouseMoving = false;
let clickTimeout = null;

let isResetting = false; // Track if reset is in delay


// Add event listeners for mouse movements and clicks
window.addEventListener('mousemove', onMouseMove, false);
window.addEventListener('click', onMouseClick, false);

// Mouse move event function
function onMouseMove(event) {
    isMouseMoving = true;
    if (clickTimeout) {
        clearTimeout(clickTimeout);
    }
    clickTimeout = setTimeout(() => {
        isMouseMoving = false;
    }, 100);
}

// Mouse click event function
function onMouseClick(event) {
    // Prevent clicks on empty spaces if a building is blinking
    if (isMouseMoving && isBlinking) return; 

    const canvasBounds = renderer.domElement.getBoundingClientRect();
    
    mouse.x = ((event.clientX - canvasBounds.left) / canvasBounds.width) * 2 - 1;
    mouse.y = -((event.clientY - canvasBounds.top) / canvasBounds.height) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);

    const intersects = raycaster.intersectObjects(scene.children, true);

    if (intersects.length > 0) {
        const clickedObject = intersects[0].object;

        if (isExcludedObject(clickedObject)) {
            return;
        }

        const parentObject = clickedObject.parent;
        const objectName = parentObject.name || clickedObject.name;

        if (!cameraSettings[objectName]) {
            console.warn('Object is not part of the camera settings and cannot be clicked:', objectName);
            return;
        }

        // Allow selection of the building
        selectSingleObject(parentObject);
    } else {
        // Only reset if the building is not blinking
        if (!isBlinking) {
            resetSelection();
        }
    }
}

function isExcludedObject(object) {
    if (object.name === "Plane") {
        return true;
    }
    
    let currentObject = object.parent;
    while (currentObject) {
        if (currentObject.name === "Plane") {
            return true;
        }
        currentObject = currentObject.parent;
    }
    
    return false;
}

const nameDisplay = document.getElementById('name-display');

function selectSingleObject(object) {
    if (isAnimating) return; // Prevent selection if animating

    // Log to check the selected object
    console.log("Selected Object:", object);

    // Hide the previously selected object's line and Start object
    if (selectedObject && selectedObject !== object) {
        resetObjectColor(selectedObject); // Reset the previous building's color
        resetSelection(); 
    }

    selectedObject = object;

    selectedObject.traverse(function (child) {
        if (child.isMesh) {
            child.selected = true;
            child.originalColor = child.originalColor || child.material.color.clone();

            const blinkDuration = 0.3; 
            const blinkTimes = 8; 
            isAnimating = true; 
            isBlinking = true; // Set the blinking flag

            // Change color to blue during blinking
            child.material.color.setRGB(0, 0, 1); 

            let blinkTween = gsap.timeline({ repeat: blinkTimes - 1, yoyo: true });
            blinkTween.to(child.material.color, { r: 0, g: 0, b: 1, duration: blinkDuration })
                .to(child.material.color, { r: child.originalColor.r, g: child.originalColor.g, b: child.originalColor.b, duration: blinkDuration });

            blinkTween.eventCallback('onComplete', () => {
                // Keep the building blue after blinking is done
                child.material.color.setRGB(0, 0, 1);
                isAnimating = false; // Allow new selections after blinking
                isBlinking = false; // Reset blinking flag
            });
        }
    });

    nameDisplay.textContent = selectedObject.name ? selectedObject.name : 'Unnamed Object';

    const settings = cameraSettings[selectedObject.name];

    if (settings) {
        gsap.to(camera.position, {
            x: settings.position.x,
            y: settings.position.y,
            z: settings.position.z,
            duration: 1,
            onUpdate: () => {
                camera.lookAt(settings.lookAt);
            }
        });

        // Show the line and Start object for the selected building
        const lineToShow = showLineForBuilding(selectedObject.name);
        if (lineToShow) {
            currentLine = lineToShow; // Update currentLine
            gsap.to(currentLine.material, { opacity: 1, duration: 1.5 }); // Fade in the line

            if (startObject) {
                startObject.visible = true; // Show the Start object when a building is clicked
            }
        }
    } else {
        console.warn('No camera settings found for this object');
    }
}



function resetSelection() {
    // Hide the currently visible line and Start object
    if (currentLine) {
        gsap.to(currentLine.material, { opacity: 0, duration: 0.5, onComplete: () => { currentLine.visible = false; } });
        currentLine = null; // Reset currentLine
    }

    if (startObject) {
        startObject.visible = false; // Hide Start object
    }

    // Hide all lines
    const lines = [yellowLine, bautistaLine, adminLine, mulitLine, danceLine, acadLine, chedLine, belmonteLine, techvocLine];
    lines.forEach(line => {
        if (line) {
            line.visible = false; // Hide each line
        }
    });

    // Reset the color of the currently selected building if there is one
    if (selectedObject) {
        resetObjectColor(selectedObject); // Reset the color of the selected building
        selectedObject = null; // Clear the selected object
    }
}

function resetObjectColor(object) {
    object.traverse(function (child) {
        if (child.isMesh && child.selected) {
            child.material.color.copy(child.originalColor); // Reset to original color
            child.selected = false; // Clear the selected flag
        }
    });
}



let currentParking = null; // Variable to track the currently shown parking object
let highlightInterval = null; // Interval for the blinking animation

// Event listeners for the parking buttons
document.getElementById('car-parking-button').addEventListener('click', () => {
    toggleParkingVisibility('CarsParking');
});

document.getElementById('motor-parking-button').addEventListener('click', () => {
    toggleParkingVisibility('MotorParking');
});

document.getElementById('bike-parking-button').addEventListener('click', () => {
    toggleParkingVisibility('BikePark');
});

// Function to show and highlight the clicked parking area
function toggleParkingVisibility(parkingType) {
    if (currentParking === parkingType) return; // If clicked parking is already shown, do nothing

    // Hide both parking areas
    hideParkingAreas();

    // Show the selected parking area
    showAndHighlightParking(parkingType);
}

// Function to show and highlight a parking area
function showAndHighlightParking(parkingType) {
    // Traverse the scene to show the clicked parking and hide the other
    scene.traverse((object) => {
        if (object.isMesh) {
            if (object.name === parkingType) {
                currentParking = parkingType; // Update the currently visible parking
                object.visible = true; // Show the selected parking
                
                // Start the blinking animation
                let isHighlighted = false;
                highlightInterval = setInterval(() => {
                    isHighlighted = !isHighlighted;
                    object.material.emissive.setHex(isHighlighted ? 0x00008B : 0x000000); // Toggle highlight
                }, 500);
            }
        }
    });
}

// Function to hide both parking areas
function hideParkingAreas() {
    scene.traverse((object) => {
        if (object.isMesh) {
            if (object.name === "CarsParking" || object.name === "MotorParking" || object.name === "BikePark") {
                object.visible = false; // Hide parking objects
                resetHighlight(object.name); // Reset their highlight
            }
        }
    });

    // Reset currentParking state
    currentParking = null;
}

// Function to reset highlight of a parking area
function resetHighlight(parkingType) {
    scene.traverse((object) => {
        if (object.name === parkingType) {
            object.material.emissive.setHex(0x000000); // Reset to no highlight
        }
    });
}

let currentEvacuation = null; // Variable to track the currently shown evacuation area
let highlightEvacuationInterval = null; // Interval for the blinking animation

// Function to reset the evacuation area when going back
function resetEvacuationState() {
    currentEvacuation = null;
    clearInterval(highlightEvacuationInterval);
    hideEvacuationArea(); // Hide evacuation area when returning to the emergency tab
}

// Event listener for the evacuation button
document.getElementById('evacuation-button').addEventListener('click', () => {
    toggleEvacuationVisibility('Evacuation');
});

// Function to show and highlight the clicked evacuation area
function toggleEvacuationVisibility(evacuationType) {
    if (currentEvacuation === evacuationType) return; // If clicked evacuation area is already shown, do nothing

    // Hide the evacuation area
    hideEvacuationArea();

    // Show the selected evacuation area
    showAndHighlightEvacuation(evacuationType);
}

// Function to show and highlight an evacuation area
function showAndHighlightEvacuation(evacuationType) {
    // Traverse the scene to show the clicked evacuation and hide the others
    scene.traverse((object) => {
        if (object.isMesh) {
            if (object.name === evacuationType) {
                currentEvacuation = evacuationType; // Update the currently visible evacuation area
                object.visible = true; // Show the selected evacuation area
                
                // Start the blinking animation
                let isHighlighted = false;
                highlightEvacuationInterval = setInterval(() => {
                    isHighlighted = !isHighlighted;
                    object.material.emissive.setHex(isHighlighted ? 0x00008B : 0x000000); // Toggle highlight
                }, 500);
            }
        }
    });
}

// Function to hide the evacuation area
function hideEvacuationArea() {
    scene.traverse((object) => {
        if (object.isMesh) {
            if (object.name === "Evacuation") {
                object.visible = false; // Hide the evacuation area
                resetEvacuationHighlight(object.name); // Reset its highlight
            }
        }
    });

    // Reset currentEvacuation state
    currentEvacuation = null;
}

// Function to reset highlight of the evacuation area
function resetEvacuationHighlight(evacuationType) {
    scene.traverse((object) => {
        if (object.name === evacuationType) {
            object.material.emissive.setHex(0x000000); // Reset to no highlight
        }
    });
}

document.addEventListener("DOMContentLoaded", () => {
    const mainPanel = document.getElementById("main-panel");
    const subPanels = document.querySelectorAll(".sub-panel");
    const panelButtons = document.querySelectorAll(".panel-button");
    const backButtons = document.querySelectorAll(".back-button");

    // Show selected panel and hide the main panel
    panelButtons.forEach(button => {
        button.addEventListener("click", () => {
            const targetPanelId = button.getAttribute("data-panel");
            document.getElementById(targetPanelId).classList.add("active");
            mainPanel.classList.remove("active");
        });
    });

    // Back to main panel and hide the parking areas
    backButtons.forEach(button => {
        button.addEventListener("click", () => {
            subPanels.forEach(panel => panel.classList.remove("active"));
            mainPanel.classList.add("active");

            // Hide the parking areas when back button is clicked
            hideParkingAreas();

            // Reset evacuation state when going back to the main panel
            resetEvacuationState();
        });
    });

    // Show the main panel initially
    mainPanel.classList.add("active");
});

// Function to hide CarsParking and MotorParking
function hideParkingAreas() {
    if (CarsParking) {
        CarsParking.visible = false;
    }
    if (MotorParking) {
        MotorParking.visible = false;
    }
    if (BikePark) {
        BikePark.visible = false;
    }
    if (Evacuation) {
        Evacuation.visible = false;
    }
}

// Add click event listener to the window
window.addEventListener('click', handleClick);


window.addEventListener('resize', function () {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth * 0.7, window.innerHeight);
});

animate();